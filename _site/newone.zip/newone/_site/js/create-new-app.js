(function($) {
  $(document).ready(function(){
    function ready() {
      // Initialize the custom-select select box.
      $(".custom-select").customselect();

      $('.createNewApp .row').hover(
        function(){ $(this).addClass('active') },
        function(){ $(this).removeClass('active') }
      );
      i = 1;
      $(".counter").each(function() {
          $(this).text(i++);
        });
      $(".addCF").remove();
      if(!$("#customFields .row:last-child .cross .addCF").length) {
        $("#customFields .row:last-child .cross").append('<span class="plus addCF" > | +</span>');
      }
      $(".addCF").on("click", function() {
        var row = '<div class="row">' + $("#customFields .row").html() + '</div>';
        var row = '<div class="row">' +
                '<div class="left-cont">' +
                '<span class="counter"></span><input type="text" value="" name="" placeholder="Enter page name"/>' +
              '</div>' +
              
              '<div class="right-cont">' +
                 '<select  name="standard" class="custom-select">' +
                  '<option value="">Select a Template</option>' +
                  '<option value="1">Template 001</option>' +
                  '<option value="2">Template 002</option>' +
                  '<option value="3">Template 003</option>' +
                  '<option value="4">Template 004</option>' +
                  '<option value="5">Template 005</option>' +
                  '<option value="6">Template 006</option>' +
                  '<option value="7">Template 007</option>' +
                  '</select>' +
              '</div>' +
              '<div class="cross"><span class="remove">X</span></div>' +
              '<div class="clearfix"></div>' +
            '</div>';
        $("#customFields").append(row);
        ready();
      });
      $("#customFields .cross .remove").on("click", function(){
        $(this).parent().parent().remove();
        ready();
      });
      $('#customFields .create-tmplate').on('click', function() {
        $(".pop-up").show(); 
        ready();
      });
      $('.close-cross').on('click', function() {
        $(this).parent().hide();
        ready(); 
      });
      $('.graph-select .create-tmplate').on('click', function() {
        $(".pop-up").hide();
        $(".create-graph-popup").show();
        ready();
      });
      
      $(".graph-select .templatList .create-tmplate a").text("Create New Graph");
    }
    ready();
    $("div.toggle").on('click', function(){
        $(".show--menu").toggle();
    });
  });
})(jQuery);