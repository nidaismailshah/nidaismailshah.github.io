import React, {StyleSheet, Dimensions, PixelRatio} from "react-native";
const {width, height, scale} = Dimensions.get("window"),
    vw = width / 100,
    vh = height / 100,
    vmin = Math.min(vw, vh),
    vmax = Math.max(vw, vh);

export default StyleSheet.create({
    "body": {
        "marginTop": 0,
        "marginRight": 0,
        "marginBottom": 0,
        "marginLeft": 0,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0,
        "fontFamily": "'latolight'",
        "fontSize": 16,
        "lineHeight": 22,
        "color": "#ababab",
        "background": "#f7f7f7"
    },
    "div": {
        "marginTop": 0,
        "marginRight": 0,
        "marginBottom": 0,
        "marginLeft": 0,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0
    },
    "p": {
        "marginTop": 0,
        "marginRight": 0,
        "marginBottom": 0,
        "marginLeft": 0,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0
    },
    "span": {
        "marginTop": 0,
        "marginRight": 0,
        "marginBottom": 0,
        "marginLeft": 0,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0
    },
    "strong": {
        "marginTop": 0,
        "marginRight": 0,
        "marginBottom": 0,
        "marginLeft": 0,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0
    },
    "h1": {
        "marginTop": 0,
        "marginRight": 0,
        "marginBottom": 0,
        "marginLeft": 0,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0,
        "fontSize": 40,
        "lineHeight": 46,
        "fontWeight": "normal",
        "color": "#0093fc"
    },
    "h2": {
        "marginTop": 0,
        "marginRight": 0,
        "marginBottom": 0,
        "marginLeft": 0,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0,
        "fontSize": 24,
        "lineHeight": 28,
        "fontWeight": "normal",
        "color": "#0093fc"
    },
    "h3": {
        "marginTop": 0,
        "marginRight": 0,
        "marginBottom": 0,
        "marginLeft": 0,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0
    },
    "h4": {
        "marginTop": 0,
        "marginRight": 0,
        "marginBottom": 0,
        "marginLeft": 0,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0
    },
    "h5": {
        "marginTop": 0,
        "marginRight": 0,
        "marginBottom": 0,
        "marginLeft": 0,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0
    },
    "h6": {
        "marginTop": 0,
        "marginRight": 0,
        "marginBottom": 0,
        "marginLeft": 0,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0
    },
    "a": {
        "marginTop": 0,
        "marginRight": 0,
        "marginBottom": 0,
        "marginLeft": 0,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0
    },
    "img": {
        "marginTop": 0,
        "marginRight": 0,
        "marginBottom": 0,
        "marginLeft": 0,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0,
        "maxWidth": "100%"
    },
    "ol": {
        "marginTop": 0,
        "marginRight": 0,
        "marginBottom": 0,
        "marginLeft": 0,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0
    },
    "ul": {
        "marginTop": 0,
        "marginRight": 0,
        "marginBottom": 0,
        "marginLeft": 0,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0
    },
    "li": {
        "marginTop": 0,
        "marginRight": 0,
        "marginBottom": 0,
        "marginLeft": 0,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0
    },
    "table": {
        "marginTop": 0,
        "marginRight": 0,
        "marginBottom": 0,
        "marginLeft": 0,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0
    },
    "tr": {
        "marginTop": 0,
        "marginRight": 0,
        "marginBottom": 0,
        "marginLeft": 0,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0
    },
    "td": {
        "marginTop": 0,
        "marginRight": 0,
        "marginBottom": 0,
        "marginLeft": 0,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0
    },
    "body img": {
        "border": "none",
        "display": "block"
    },
    "body a": {
        "textDecoration": "none",
        "color": "#0093fc"
    },
    "body a:hover": {
        "textDecoration": "none",
        "color": "#787a7a"
    },
    "body a:focus": {
        "outline": "none"
    },
    "body a:visited": {
        "outline": "none"
    },
    "body ul": {
        "listStyle": "none"
    },
    "body ol": {
        "listStyle": "none"
    },
    "clearfix": {
        "clear": "both"
    },
    "wrapper": {
        "position": "relative",
        "maxWidth": 1250,
        "paddingTop": 15,
        "paddingRight": 15,
        "paddingBottom": 15,
        "paddingLeft": 15,
        "marginTop": 0,
        "marginRight": "auto",
        "marginBottom": 0,
        "marginLeft": "auto",
        "background": "#fff"
    },
    "wrapperlogin": {
        "background": "none",
        "paddingTop": 0,
        "paddingRight": 15,
        "paddingBottom": 0,
        "paddingLeft": 15
    },
    "read-more": {
        "fontWeight": "bold"
    },
    "loginPanel left-cont": {
        "width": "100%",
        "marginBottom": 15,
        "paddingTop": "7%",
        "paddingRight": "5%",
        "paddingBottom": "7%",
        "paddingLeft": "5%",
        "boxSizing": "border-box",
        "background": "#fff",
        "position": "relative"
    },
    "loginPanel left-cont copyright": {
        "position": "absolute",
        "bottom": 20,
        "left": "5%",
        "display": "none"
    },
    "loginPanel right-cont": {
        "width": "100%",
        "background": "#e1e3e3",
        "paddingTop": "7%",
        "paddingRight": "5%",
        "paddingBottom": "7%",
        "paddingLeft": "5%",
        "boxSizing": "border-box"
    },
    "loginPanel logo": {
        "display": "block",
        "textTransform": "uppercase",
        "fontSize": 42,
        "lineHeight": 48
    },
    "loginPanel logo:hover": {
        "color": "#0093fc"
    },
    "loginPanel logo strong": {
        "fontFamily": "'latobold'"
    },
    "loginPanel left-cont span": {
        "textTransform": "uppercase",
        "fontFamily": "'latobold'"
    },
    "loginPanel h1": {
        "color": "#bdbdbd",
        "fontSize": 26,
        "lineHeight": 32
    },
    "loginPanel h2": {
        "marginBottom": 15,
        "fontSize": 20,
        "lineHeight": 26,
        "fontFamily": "'latoregular'"
    },
    "loginPanel p": {
        "marginTop": 10,
        "marginRight": 0,
        "marginBottom": 10,
        "marginLeft": 0
    },
    "loginPanel right-cont label": {
        "display": "block",
        "marginBottom": 3,
        "color": "#787a7a",
        "fontFamily": "'latoregular'"
    },
    "loginPanel right-cont input": {
        "width": "100%",
        "border": "1px solid #e1e3e3",
        "paddingTop": 12,
        "paddingRight": 7,
        "paddingBottom": 12,
        "paddingLeft": 7,
        "boxSizing": "border-box",
        "fontSize": 12,
        "color": "#7d7d7d"
    },
    "loginPanel right-cont inputBox": {
        "marginBottom": 15
    },
    "loginPanel right-cont inputBox span": {
        "fontSize": 13,
        "lineHeight": 17,
        "color": "#FF0000"
    },
    "loginPanel right-cont buttonsubmit": {
        "background": "#0093fc",
        "border": "1px solid #0093fc",
        "width": "auto",
        "color": "#fff",
        "borderColor": "#0093fc",
        "paddingTop": 8,
        "paddingRight": 18,
        "paddingBottom": 8,
        "paddingLeft": 18,
        "textTransform": "uppercase",
        "fontWeight": "bold",
        "cursor": "pointer"
    },
    "loginPanel right-cont buttonsubmit:hover": {
        "background": "#fff",
        "color": "#0093fc"
    },
    "loginPanel right-cont ForgetPassword": {
        "display": "block",
        "marginBottom": 15,
        "fontSize": 14,
        "lineHeight": 18,
        "fontFamily": "'latoregular'"
    },
    "copyrightFooter": {
        "background": "#fff"
    },
    "rememberBox": {
        "marginTop": 20,
        "marginRight": 0,
        "marginBottom": 15,
        "marginLeft": 0
    },
    "rememberBox btn": {
        "float": "left",
        "width": 60,
        "marginRight": 10
    },
    "rememberBox rememberText": {
        "float": "left",
        "width": "75%",
        "paddingTop": 5,
        "paddingRight": 0,
        "paddingBottom": 5,
        "paddingLeft": 0,
        "color": "#787a7a",
        "fontSize": 14,
        "lineHeight": 18,
        "fontFamily": "'latoregular'"
    },
    "formminimal input[type=\"text\"]": {
        "position": "absolute",
        "marginLeft": -9999,
        "visibility": "hidden"
    },
    "formminimal input[type=\"password\"]": {
        "position": "absolute",
        "marginLeft": -9999,
        "visibility": "hidden"
    },
    "formminimal input[type=\"text\"]:focus": {
        "position": "absolute",
        "marginLeft": -9999,
        "visibility": "hidden"
    },
    "formminimal input[type=\"password\"]:focus": {
        "position": "absolute",
        "marginLeft": -9999,
        "visibility": "hidden"
    },
    "formminimal input[type=\"text\"]:invalid:focus": {
        "position": "absolute",
        "marginLeft": -9999,
        "visibility": "hidden"
    },
    "formminimal input[type=\"password\"]:invalid:focuscmn-toggle": {
        "position": "absolute",
        "marginLeft": -9999,
        "visibility": "hidden"
    },
    "cmn-toggle + label": {
        "display": "block",
        "position": "relative",
        "cursor": "pointer",
        "outline": "none",
        "WebkitUserSelect": "none",
        "MozUserSelect": "none",
        "MsUserSelect": "none",
        "userSelect": "none"
    },
    "inputcmn-toggle-round + label": {
        "paddingTop": 2,
        "paddingRight": 2,
        "paddingBottom": 2,
        "paddingLeft": 2,
        "width": 120,
        "height": 60,
        "backgroundColor": "#dddddd",
        "WebkitBorderRadius": 60,
        "MozBorderRadius": 60,
        "MsBorderRadius": 60,
        "OBorderRadius": 60,
        "borderRadius": 60
    },
    "inputcmn-toggle-round + label:before": {
        "display": "block",
        "position": "absolute",
        "top": 1,
        "left": 1,
        "bottom": 1,
        "content": "",
        "right": 1,
        "backgroundColor": "#f1f1f1",
        "WebkitBorderRadius": 60,
        "MozBorderRadius": 60,
        "MsBorderRadius": 60,
        "OBorderRadius": 60,
        "borderRadius": 60,
        "WebkitTransition": "background 0.4s",
        "MozTransition": "background 0.4s",
        "OTransition": "background 0.4s",
        "transition": "background 0.4s"
    },
    "inputcmn-toggle-round + label:after": {
        "display": "block",
        "position": "absolute",
        "top": 1,
        "left": 1,
        "bottom": 1,
        "content": "",
        "width": 58,
        "backgroundColor": "#fff",
        "WebkitBorderRadius": "100%",
        "MozBorderRadius": "100%",
        "MsBorderRadius": "100%",
        "OBorderRadius": "100%",
        "borderRadius": "100%",
        "WebkitBoxShadow": "0 2px 5px rgba(0, 0, 0, 0.3)",
        "MozBoxShadow": "0 2px 5px rgba(0, 0, 0, 0.3)",
        "boxShadow": "0 2px 5px rgba(0, 0, 0, 0.3)",
        "WebkitTransition": "margin 0.4s",
        "MozTransition": "margin 0.4s",
        "OTransition": "margin 0.4s",
        "transition": "margin 0.4s"
    },
    "inputcmn-toggle-round:checked + label:before": {
        "backgroundColor": "#8ce196"
    },
    "inputcmn-toggle-round:checked + label:after": {
        "marginLeft": 60
    },
    "inputcmn-toggle-round-flat + label": {
        "paddingTop": 2,
        "paddingRight": 2,
        "paddingBottom": 2,
        "paddingLeft": 2,
        "width": 55,
        "height": 25,
        "backgroundColor": "#dddddd",
        "WebkitBorderRadius": 60,
        "MozBorderRadius": 60,
        "MsBorderRadius": 60,
        "OBorderRadius": 60,
        "borderRadius": 60,
        "WebkitTransition": "background 0.4s",
        "MozTransition": "background 0.4s",
        "OTransition": "background 0.4s",
        "transition": "background 0.4s"
    },
    "inputcmn-toggle-round-flat + label:before": {
        "display": "block",
        "position": "absolute",
        "content": "",
        "top": 2,
        "left": 2,
        "bottom": 2,
        "right": 2,
        "backgroundColor": "#fff",
        "WebkitBorderRadius": 60,
        "MozBorderRadius": 60,
        "MsBorderRadius": 60,
        "OBorderRadius": 60,
        "borderRadius": 60,
        "WebkitTransition": "background 0.4s",
        "MozTransition": "background 0.4s",
        "OTransition": "background 0.4s",
        "transition": "background 0.4s"
    },
    "inputcmn-toggle-round-flat + label:after": {
        "display": "block",
        "position": "absolute",
        "content": "",
        "top": 4,
        "left": 4,
        "bottom": 4,
        "width": 22,
        "backgroundColor": "#dddddd",
        "WebkitBorderRadius": 52,
        "MozBorderRadius": 52,
        "MsBorderRadius": 52,
        "OBorderRadius": 52,
        "borderRadius": 52,
        "WebkitTransition": "margin 0.4s, background 0.4s",
        "MozTransition": "margin 0.4s, background 0.4s",
        "OTransition": "margin 0.4s, background 0.4s",
        "transition": "margin 0.4s, background 0.4s"
    },
    "inputcmn-toggle-round-flat:checked + label": {
        "backgroundColor": "#0093fc"
    },
    "inputcmn-toggle-round-flat:checked + label:after": {
        "marginLeft": 30,
        "backgroundColor": "#0093fc"
    },
    "header": {
        "marginBottom": 5
    },
    "header leftCont": {
        "float": "left",
        "width": 53,
        "display": "none"
    },
    "header rightCont": {
        "float": "right",
        "background": "#ccebff",
        "textAlign": "right",
        "width": "100%",
        "paddingTop": 6,
        "paddingRight": 15,
        "paddingBottom": 5,
        "paddingLeft": 15,
        "boxSizing": "border-box"
    },
    "header rightCont left-cont": {
        "float": "left",
        "textTransform": "uppercase",
        "fontSize": 36,
        "lineHeight": 41
    },
    "header rightCont left-cont a:hover": {
        "color": "#0093fc"
    },
    "header rightCont left-cont strong": {
        "fontFamily": "'latobold'"
    },
    "header rightCont right-cont": {
        "float": "right"
    },
    "header rightCont right-cont a": {
        "display": "inline-block",
        "width": 33,
        "height": 33,
        "background": "url(../pix/people_icon.png) no-repeat",
        "marginLeft": 4,
        "marginTop": 3
    },
    "header rightCont right-cont asettings": {
        "background": "url(../pix/gear_icon.png) no-repeat"
    },
    "header rightCont right-cont ahelp": {
        "background": "url(../pix/info_icon.png) no-repeat"
    },
    "header rightCont right-cont  span": {
        "color": "#0093fc",
        "display": "inline-block",
        "cursor": "pointer",
        "paddingTop": 10,
        "paddingRight": 20,
        "paddingBottom": 10,
        "paddingLeft": 0,
        "verticalAlign": "top",
        "fontFamily": "'latobold'",
        "background": "url(../pix/down_arrow.png) center right no-repeat"
    },
    "header rightCont right-cont  span:hover": {
        "color": "#ababab"
    },
    "footer": {
        "background": "#ededed",
        "paddingTop": 5,
        "paddingRight": 5,
        "paddingBottom": 5,
        "paddingLeft": 5
    },
    "page-container left-cont": {
        "width": "100%"
    },
    "page-container left-cont ul": {
        "textAlign": "center",
        "borderBottom": "2px solid #ccc"
    },
    "page-container left-cont li": {
        "display": "inline-block",
        "width": "26%",
        "textAlign": "center",
        "verticalAlign": "top",
        "borderRight": "2px solid #ccc",
        "paddingTop": 5,
        "paddingRight": "2%",
        "paddingBottom": 5,
        "paddingLeft": "2%"
    },
    "page-container left-cont lilast": {
        "borderRight": "none"
    },
    "page-container left-cont li  p": {
        "display": "none"
    },
    "page-container left-cont pabout": {
        "paddingTop": 20,
        "paddingRight": 20,
        "paddingBottom": 20,
        "paddingLeft": 20,
        "display": "none"
    },
    "page-container left-cont pabout a": {
        "display": "block",
        "marginTop": 10
    },
    "page-container left-cont li h2": {
        "fontSize": 16,
        "lineHeight": 22,
        "fontFamily": "'latobold'"
    },
    "page-container left-cont li h2 a": {
        "color": "#707070"
    },
    "page-container left-cont li:hover h2 a": {
        "color": "#0093fc"
    },
    "page-container left-cont liactive h2 a": {
        "color": "#0093fc"
    },
    "page-container right-cont": {
        "width": "100%",
        "position": "relative"
    },
    "displayBox": {
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0,
        "boxSizing": "border-box",
        "borderBottom": "2px solid #ccc"
    },
    "displayBox counters": {
        "background": "#e6f5ff"
    },
    "ActiveBox": {
        "marginTop": 20,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0,
        "marginBottom": 30
    },
    "activeTemplate": {
        "marginTop": 20,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0,
        "marginBottom": 30
    },
    "cd-tabs-navigation li icon": {
        "background": "url(../pix/apps_icon.png) no-repeat",
        "width": 35,
        "height": 35,
        "display": "block",
        "marginTop": 0,
        "marginRight": "auto",
        "marginBottom": 0,
        "marginLeft": "auto"
    },
    "cd-tabs-navigation li:hover icon": {
        "background": "url(../pix/apps_icon.png) no-repeat"
    },
    "cd-tabs-navigation li aselected icon": {
        "background": "url(../pix/apps_icon.png) no-repeat"
    },
    "cd-tabs-content li": {
        "paddingTop": 0,
        "paddingRight": "6%",
        "paddingBottom": 0,
        "paddingLeft": "6%"
    },
    "cd-tabs-navigation litab2 icon": {
        "background": "url(../pix/graphs_icon.png) no-repeat"
    },
    "cd-tabs-navigation litab2:hover icon": {
        "background": "url(../pix/graphs_icon.png) no-repeat"
    },
    "cd-tabs-navigation litab2 aselected icon": {
        "background": "url(../pix/graphs_icon.png) no-repeat"
    },
    "cd-tabs-navigation lilast icon": {
        "background": "url(../pix/templates_icon.png) no-repeat"
    },
    "cd-tabs-navigation lilast:hover icon": {
        "background": "url(../pix/templates_icon.png) no-repeat"
    },
    "cd-tabs-navigation lilast aselected icon": {
        "background": "url(../pix/templates_icon.png) no-repeat"
    },
    "cd-tabs-content li column": {
        "borderBottom": "2px solid #b3e0ff",
        "boxSizing": "border-box",
        "width": "100%",
        "paddingTop": 10,
        "paddingRight": 0,
        "paddingBottom": 10,
        "paddingLeft": 0
    },
    "cd-tabs-content li columnlast": {
        "border": "none"
    },
    "cd-tabs-content li column span": {
        "display": "block",
        "marginBottom": 5,
        "fontFamily": "'latoregular'"
    },
    "cd-tabs-content li column spantotalCount": {
        "color": "#0093fc",
        "fontSize": 30,
        "lineHeight": 36,
        "fontFamily": "'latolight'"
    },
    "ActiveBox row ul li": {
        "background": "#f8f8f8",
        "borderTop": "2px solid #ccc",
        "boxSizing": "border-box",
        "paddingTop": 7,
        "paddingRight": 10,
        "paddingBottom": 7,
        "paddingLeft": 10,
        "position": "relative",
        "marginBottom": 10
    },
    "activeTemplate row ul li": {
        "background": "#f8f8f8",
        "borderTop": "2px solid #ccc",
        "boxSizing": "border-box",
        "paddingTop": 7,
        "paddingRight": 10,
        "paddingBottom": 7,
        "paddingLeft": 10,
        "position": "relative",
        "marginBottom": 10
    },
    "ActiveBox row ul li span": {
        "display": "block"
    },
    "activeTemplate row ul li span": {
        "display": "block"
    },
    "ActiveBox row ul li spanappName": {
        "fontFamily": "'latobold'",
        "fontSize": 18,
        "lineHeight": 26
    },
    "activeTemplate row ul li spanappName": {
        "fontFamily": "'latobold'",
        "fontSize": 18,
        "lineHeight": 26
    },
    "ActiveBox row ul li option": {
        "position": "absolute",
        "right": 10,
        "top": 10
    },
    "activeTemplate row ul li option": {
        "position": "absolute",
        "right": 10,
        "top": 10
    },
    "headingPanel": {
        "borderBottom": "2px solid #f1f1f1",
        "paddingBottom": 6,
        "marginBottom": 10
    },
    "headingPanel h2": {
        "fontFamily": "'latobold'",
        "display": "inline-block",
        "verticalAlign": "middle"
    },
    "headingPanel leftcont": {
        "width": "100%",
        "float": "left"
    },
    "headingPanel rightcont": {
        "width": "45%",
        "textAlign": "right",
        "float": "right",
        "display": "none"
    },
    "headingPanel rightcont div": {
        "display": "none",
        "marginLeft": 25,
        "verticalAlign": "top"
    },
    "headingPanel rightcont divview-all": {
        "display": "inline-block"
    },
    "headingPanel leftcont span": {
        "display": "inline-block",
        "background": "url(../pix/filter_icon.png) center 10px no-repeat",
        "marginTop": 0,
        "marginRight": 3,
        "marginBottom": 0,
        "marginLeft": 5,
        "width": 25,
        "height": 25,
        "verticalAlign": "middle",
        "position": "relative"
    },
    "headingPanel leftcont span:hover": {
        "background": "url(../pix/filter_icon.png) center 10px no-repeat",
        "cursor": "pointer"
    },
    "headingPanel leftcont spanremove": {
        "background": "url(../pix/trash_icon.png) center 8px no-repeat"
    },
    "headingPanel leftcont spanremove:hover": {
        "background": "url(../pix/trash_icon.png) center 8px no-repeat"
    },
    "headingPanel leftcont spanoptions": {
        "background": "url(../pix/small_down_arrow.png)center 13px no-repeat"
    },
    "headingPanel leftcont spanoptions:hover": {
        "background": "url(../pix/small_down_arrow.png) center 13px no-repeat"
    },
    "headingPanel leftcont span ul": {
        "position": "absolute",
        "top": 34,
        "left": 0,
        "background": "#0093fc",
        "paddingTop": 10,
        "paddingRight": 10,
        "paddingBottom": 10,
        "paddingLeft": 10,
        "boxSizing": "border-box",
        "zIndex": 1,
        "width": 140,
        "fontFamily": "'latoregular'",
        "display": "none"
    },
    "headingPanel leftcont span ul li": {
        "borderBottom": "1px solid #fff",
        "paddingTop": 5,
        "paddingRight": 0,
        "paddingBottom": 5,
        "paddingLeft": 0
    },
    "headingPanel leftcont span ul lilast": {
        "borderBottom": "none"
    },
    "headingPanel leftcont span ul li a": {
        "color": "#fff"
    },
    "headingPanel leftcont span ul li:hover a": {
        "color": "#121212"
    },
    "headingPanel leftcont spanfilters:hover > ul": {
        "display": "block"
    },
    "headingPanel leftcont spanoptions:hover > ul": {
        "display": "block"
    },
    "ActiveBox headingPanel rightcont views thumbviewIcon": {
        "background": "url(../pix/menu_icon.png) no-repeat",
        "width": 15,
        "height": 15,
        "display": "inline-block",
        "marginTop": 0,
        "marginRight": 2,
        "marginBottom": 0,
        "marginLeft": 2,
        "cursor": "pointer"
    },
    "ActiveBox headingPanel rightcont views thumbviewIcon:hover": {
        "background": "url(../pix/menu_icon.png) no-repeat",
        "width": 15,
        "height": 15
    },
    "ActiveBox headingPanel rightcont views thumbviewIconactive": {
        "background": "url(../pix/menu_icon.png) no-repeat",
        "width": 15,
        "height": 15
    },
    "ActiveBox headingPanel rightcont views listviewIcon": {
        "background": "url(../pix/menu_icon.png) no-repeat",
        "width": 15,
        "height": 15,
        "display": "inline-block",
        "marginTop": 0,
        "marginRight": 2,
        "marginBottom": 0,
        "marginLeft": 2,
        "cursor": "pointer",
        "backgroundPosition": "-24px 0"
    },
    "ActiveBox headingPanel rightcont views listviewIcon:hover": {
        "background": "url(../pix/menu_icon.png) no-repeat",
        "width": 15,
        "height": 15,
        "backgroundPosition": "-24px 0"
    },
    "ActiveBox headingPanel rightcont views listviewIconactive": {
        "background": "url(../pix/menu_icon.png) no-repeat",
        "width": 15,
        "height": 15,
        "backgroundPosition": "-24px 0"
    },
    "headingPanel rightcont divviews": {
        "marginTop": 5
    },
    "ActiveBox listView table": {
        "width": "100%"
    },
    "ActiveBox listView table th": {
        "paddingTop": 10,
        "paddingRight": 10,
        "paddingBottom": 10,
        "paddingLeft": 10,
        "boxSizing": "border-box",
        "textAlign": "left",
        "borderTop": "1px solid #f0f0f0",
        "background": "#f8f8f8"
    },
    "ActiveBox listView table td": {
        "paddingTop": 10,
        "paddingRight": 10,
        "paddingBottom": 10,
        "paddingLeft": 10,
        "boxSizing": "border-box",
        "textAlign": "left",
        "borderTop": "1px solid #f0f0f0"
    },
    "activeTemplate headingPanel rightcont views thumbviewIcon": {
        "background": "url(../pix/menu_icon.png) no-repeat",
        "width": 15,
        "height": 15,
        "display": "inline-block",
        "marginTop": 0,
        "marginRight": 2,
        "marginBottom": 0,
        "marginLeft": 2,
        "cursor": "pointer"
    },
    "activeTemplate headingPanel rightcont views thumbviewIcon:hover": {
        "background": "url(../pix/menu_icon.png) no-repeat",
        "width": 15,
        "height": 15
    },
    "activeTemplate headingPanel rightcont views thumbviewIconactive": {
        "background": "url(../pix/menu_icon.png) no-repeat",
        "width": 15,
        "height": 15
    },
    "activeTemplate headingPanel rightcont views listviewIcon": {
        "background": "url(../pix/menu_icon.png) no-repeat",
        "width": 15,
        "height": 15,
        "display": "inline-block",
        "marginTop": 0,
        "marginRight": 2,
        "marginBottom": 0,
        "marginLeft": 2,
        "cursor": "pointer",
        "backgroundPosition": "-24px 0"
    },
    "activeTemplate headingPanel rightcont views listviewIcon:hover": {
        "background": "url(../pix/menu_icon.png) no-repeat",
        "width": 15,
        "height": 15,
        "backgroundPosition": "-24px 0"
    },
    "activeTemplate headingPanel rightcont views listviewIconactive": {
        "background": "url(../pix/menu_icon.png) no-repeat",
        "width": 15,
        "height": 15,
        "backgroundPosition": "-24px 0"
    },
    "activeTemplate listView table": {
        "width": "100%"
    },
    "activeTemplate listView table th": {
        "paddingTop": 10,
        "paddingRight": 10,
        "paddingBottom": 10,
        "paddingLeft": 10,
        "boxSizing": "border-box",
        "textAlign": "left",
        "borderTop": "1px solid #f0f0f0",
        "background": "#f8f8f8"
    },
    "activeTemplate listView table td": {
        "paddingTop": 10,
        "paddingRight": 10,
        "paddingBottom": 10,
        "paddingLeft": 10,
        "boxSizing": "border-box",
        "textAlign": "left",
        "borderTop": "1px solid #f0f0f0"
    },
    "boxContent": {
        "paddingTop": 20,
        "paddingRight": 0,
        "paddingBottom": 20,
        "paddingLeft": 0,
        "boxSizing": "border-box"
    },
    "createNewApp appDetails": {
        "borderBottom": "2px solid #ccc",
        "paddingBottom": 20,
        "marginBottom": 20
    },
    "createNewApp appDetails leftCont": {
        "float": "left",
        "width": "55%"
    },
    "createNewApp appDetails leftCont inputBox": {
        "position": "relative",
        "background": "#e6f5ff"
    },
    "createNewApp appDetails rightCont": {
        "float": "right",
        "width": "35%"
    },
    "createNewApp appDetails leftCont cd-dropdown > span:after": {
        "background": "#fff"
    },
    "createNewApp appDetails leftCont cd-dropdown > span::after": {
        "top": 0,
        "height": "100%",
        "fontSize": 22,
        "lineHeight": 38
    },
    "createNewApp appDetails leftCont cd-dropdown > span": {
        "paddingTop": 17,
        "paddingRight": 15,
        "paddingBottom": 17,
        "paddingLeft": 15
    },
    "createNewApp appDetails leftCont  cd-dropdown ul li": {
        "width": "92% !important"
    },
    "createNewApp appDetails label": {
        "display": "block",
        "marginBottom": 8,
        "fontFamily": "'latobold'",
        "color": "#737370"
    },
    "detailsPages  label": {
        "display": "block",
        "marginBottom": 8,
        "fontFamily": "'latobold'",
        "color": "#737370"
    },
    "createNewApp appDetails input": {
        "width": "85%",
        "paddingTop": 17,
        "paddingRight": 10,
        "paddingBottom": 17,
        "paddingLeft": 10,
        "boxSizing": "border-box",
        "border": "none",
        "color": "#737370",
        "background": "#e6f5ff",
        "fontFamily": "'latobold'",
        "verticalAlign": "top"
    },
    "createNewApp row input": {
        "width": "71%",
        "paddingTop": 17,
        "paddingRight": 10,
        "paddingBottom": 17,
        "paddingLeft": 10,
        "boxSizing": "border-box",
        "border": "none",
        "color": "#737370",
        "background": "#e6f5ff",
        "fontFamily": "'latobold'",
        "verticalAlign": "top"
    },
    "createNewApp appDetails leftCont editIcon": {
        "background": "url(../pix/edit_app_icon.png) center right no-repeat",
        "position": "absolute",
        "right": 12,
        "top": 15,
        "width": 25,
        "height": 25,
        "display": "block"
    },
    "createNewApp appDetails rightCont input": {
        "width": "100%"
    },
    "createNewApp row": {
        "marginBottom": 30
    },
    "createNewApp row left-cont": {
        "width": "100%",
        "marginBottom": 15
    },
    "createNewApp row left-cont span": {
        "display": "inline-block",
        "background": "url(../pix/inputbg.jpg) no-repeat",
        "fontSize": 20,
        "lineHeight": 26,
        "paddingTop": 11,
        "paddingRight": 20,
        "paddingBottom": 11,
        "paddingLeft": 20,
        "color": "#c1c1be",
        "marginRight": 1,
        "boxSizing": "border-box",
        "fontFamily": "'latoregular'"
    },
    "createNewApp row right-cont": {
        "width": "70%",
        "border": "none",
        "display": "inline-block",
        "marginRight": "5%"
    },
    "createNewApp row cross": {
        "display": "inline-block",
        "width": "20%",
        "color": "#c1c1be",
        "fontFamily": "'latoregular'",
        "fontSize": 24,
        "lineHeight": 30,
        "cursor": "pointer"
    },
    "createNewApp row cross span": {
        "display": "inline-block"
    },
    "createNewApp row cross spanremove": {
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0
    },
    "createNewApp row cross spanplus": {
        "fontSize": 28,
        "lineHeight": 34
    },
    "createNewApp row cross span:hover": {
        "color": "#0093fc"
    },
    "createRows": {
        "borderBottom": "2px solid #ccc",
        "paddingBottom": 20,
        "marginBottom": 20
    },
    "createNewApp rowactive left-cont span": {
        "color": "#999 !important"
    },
    "createNewApp rowactive cd-dropdown > span": {
        "color": "#999 !important"
    },
    "createNewApp rowactive input": {
        "color": "#999 !important"
    },
    "createNewApp rowactive custom-select a": {
        "color": "#999 !important"
    },
    "custom-selectcustom-select-open input": {
        "width": "89% !important"
    },
    "custom-select": {
        "background": "url(../pix/medium_down_arrow.png) right 10px center no-repeat !important"
    },
    "actions": {
        "textAlign": "right"
    },
    "actions a": {
        "display": "inline-block",
        "marginLeft": 10,
        "background": "#0093fc",
        "color": "#fff",
        "textTransform": "uppercase",
        "paddingTop": 8,
        "paddingRight": 15,
        "paddingBottom": 8,
        "paddingLeft": 15,
        "border": "2px solid #0093fc",
        "fontFamily": "'latobold'"
    },
    "actions a:hover": {
        "background": "#fff",
        "color": "#0093fc"
    },
    "actions acancel": {
        "background": "#fff",
        "color": "#0093fc"
    },
    "actions acancel:hover": {
        "background": "#0093fc",
        "color": "#fff"
    },
    "templatList": {
        "position": "relative"
    },
    "templatList create-tmplate": {
        "position": "absolute",
        "bottom": -43,
        "left": -5,
        "width": "100%",
        "zIndex": 1,
        "overflowY": "hidden !important",
        "color": "#fff",
        "background": "url(../pix/template_icon_white.png) right 34px center no-repeat #0093fc"
    },
    "createNewApp rowactive custom-select templatList create-tmplate a": {
        "color": "#fff !important"
    },
    "templatList create-tmplate a": {
        "color": "#fff !important",
        "height": "auto !important",
        "boxSizing": "border-box"
    },
    "custom-select > div": {
        "overflow": "visible !important"
    },
    "outer-template--popup": {
        "backgroundColor": "#0093fc",
        "opacity": 0.95
    },
    "create-graph-popup upper--wrapper": {
        "display": "inline-block",
        "width": "auto",
        "paddingTop": 0
    },
    "template-popup": {
        "width": "90%",
        "marginTop": 10,
        "marginRight": "auto",
        "marginBottom": "auto",
        "marginLeft": "auto"
    },
    "upper--wrapper": {
        "display": "inline-block",
        "width": "100%",
        "paddingTop": 1
    },
    "external-wrap": {
        "paddingTop": 1,
        "marginBottom": 25
    },
    "upper--wrapper inputBox": {
        "float": "left",
        "width": "70%",
        "display": "inline-block",
        "verticalAlign": "top",
        "position": "relative"
    },
    "upper--wrapper  template-presets": {
        "display": "inline-block",
        "verticalAlign": "top"
    },
    "outer--layout-wrapper": {
        "marginTop": -6,
        "marginBottom": 2,
        "display": "none"
    },
    "outer-template--popup graphs": {
        "marginTop": 1
    },
    "input--nobg": {
        "fontFamily": "'latobold'",
        "fontSize": 20,
        "color": "#737370",
        "width": "100%",
        "lineHeight": 26,
        "border": "none",
        "verticalAlign": "top",
        "boxSizing": "border-box",
        "paddingTop": 14,
        "paddingRight": 10,
        "paddingBottom": 14,
        "paddingLeft": 10
    },
    "template-popup inputBox input--nobg": {
        "display": "inline-block",
        "verticalAlign": "middle"
    },
    "template-popup inputBox input--layover": {
        "display": "inline-block",
        "verticalAlign": "middle",
        "cursor": "pointer",
        "right": 21,
        "position": "absolute",
        "top": "29%"
    },
    "outer-presets": {
        "float": "right",
        "display": "inline-block",
        "textAlign": "right",
        "verticalAlign": "top"
    },
    "template-presets": {
        "fontSize": 16,
        "backgroundColor": "rgba(247, 247, 247, 0.2)",
        "color": "#fff",
        "textAlign": "center",
        "paddingTop": 15,
        "paddingRight": 15,
        "paddingBottom": 40,
        "paddingLeft": 15,
        "border": "1px solid #a2d7ff"
    },
    "template-presets toggle": {
        "background": "url(../pix/down_arrow_white.png) center no-repeat !important",
        "textIndent": -9999,
        "cursor": "pointer",
        "display": "inline-block",
        "width": 30
    },
    "layout-builder img": {
        "opacity": 0.5
    },
    "layout-builder img:hover": {
        "opacity": 1,
        "background": "url(../pix/eye_ion.png)"
    },
    "right--img": {
        "display": "inline-block"
    },
    "left--img": {
        "display": "inline-block"
    },
    "layout-builder": {
        "display": "inline-block"
    },
    "graph--layout": {
        "textAlign": "center",
        "backgroundColor": "rgba(247, 247, 247, 0.2)",
        "border": "1px solid #a2d7ff"
    },
    "graph--layout img": {
        "display": "inline-block",
        "cursor": "pointer",
        "marginTop": 16,
        "marginRight": 16,
        "marginBottom": 16,
        "marginLeft": 16
    },
    "template-popup graph": {
        "display": "inline-block",
        "marginRight": 2
    },
    "template-popup graph custom-select": {
        "width": "inherit"
    },
    "wrapper--graph": {
        "display": "inline-block",
        "verticalAlign": "top"
    },
    "wrapper--graph graph": {
        "marginBottom": 30
    },
    "wrapper--graph graph img:hover": {
        "opacity": 0.5,
        "cursor": "move"
    },
    "graph custom-select": {
        "backgroundColor": "#ffffff !important"
    },
    "graph custom-select a span": {
        "width": "80%"
    },
    "graph img": {
        "cursor": "pointer"
    },
    "template-popup custom-select > div": {
        "left": "10px !important",
        "width": "80% !important"
    },
    "template-popup custom-select templatList input": {
        "paddingTop": 7,
        "paddingRight": 7,
        "paddingBottom": 7,
        "paddingLeft": 7
    },
    "template-popup custom-select div ul li": {
        "fontSize": 12,
        "opacity": 0.8,
        "color": "#000000 !important"
    },
    "template-popup custom-select div ul li:hover": {
        "color": "#fff !important",
        "background": "#9A9A9A"
    },
    "template-popup footer-menu": {
        "textAlign": "right",
        "paddingTop": 1,
        "paddingRight": 0,
        "paddingBottom": 1,
        "paddingLeft": 0
    },
    "template-popup footer-menu p": {
        "display": "inline-block",
        "verticalAlign": "middle",
        "color": "#fff",
        "letterSpacing": 0.3
    },
    "template-popup footer-menu submit": {
        "display": "inline-block",
        "verticalAlign": "middle",
        "color": "#0093fc",
        "letterSpacing": 0.3,
        "backgroundColor": "#fff",
        "paddingTop": 10,
        "paddingRight": 10,
        "paddingBottom": 10,
        "paddingLeft": 10,
        "marginLeft": 1
    },
    "template-popup footer-menu p span": {
        "fontSize": 22,
        "fontWeight": "bold"
    },
    "template-popup footer-menu p tag b": {
        "fontFamily": "'latobold'"
    },
    "template-popup footer-menu p tag": {
        "fontSize": 30,
        "fontWeight": "bold"
    },
    "pop-up": {
        "position": "absolute",
        "display": "none",
        "top": 0,
        "zIndex": 10
    },
    "new-template": {
        "position": "relative"
    },
    "create-graph-popup": {
        "display": "none",
        "top": 1,
        "position": "absolute",
        "width": "98%"
    },
    "close-cross": {
        "display": "inherit",
        "position": "absolute",
        "top": -5,
        "right": -10,
        "cursor": "pointer"
    },
    "imgplus": {
        "display": "inline-block",
        "position": "absolute",
        "top": "31%",
        "right": "37%"
    },
    "pop-up templatList": {
        "opacity": 0.9
    },
    "pop-up create-tmplate": {
        "backgroundColor": "#fff"
    },
    "pop-up create-tmplate a": {
        "color": "#545454 !important"
    },
    "back-to-template": {
        "float": "left",
        "display": "inline-block",
        "paddingTop": 5,
        "paddingRight": 15,
        "paddingBottom": 5,
        "paddingLeft": 15,
        "background": "#b3e0ff",
        "color": "#636363",
        "fontSize": 15,
        "lineHeight": 1.5,
        "cursor": "pointer"
    },
    "back-to-template img": {
        "display": "inline-block",
        "verticalAlign": "middle",
        "marginRight": 15
    },
    "back-to-template back-temp-text": {
        "display": "inline-block",
        "verticalAlign": "middle"
    },
    "back-to-template strong": {
        "fontFamily": "'latobold'",
        "display": "block"
    },
    "graph--landing inputBox": {
        "width": "49%"
    },
    "graph--landing template-popup footer-menu p tag": {
        "fontSize": 25
    },
    "config": {
        "display": "inline-block"
    },
    "url": {
        "display": "inline-block",
        "fontFamily": "'latobold'",
        "color": "#fff",
        "background": "#a2d7ff",
        "paddingTop": 10,
        "paddingRight": 20,
        "paddingBottom": 10,
        "paddingLeft": 20
    },
    "configure": {
        "display": "inline-block",
        "fontFamily": "'latobold'",
        "color": "#fff",
        "background": "#a2d7ff",
        "paddingTop": 10,
        "paddingRight": 20,
        "paddingBottom": 10,
        "paddingLeft": 20,
        "marginLeft": -4
    },
    "urlactive": {
        "background": "#fff",
        "color": "#636363"
    },
    "configureactive": {
        "background": "#fff",
        "color": "#636363"
    },
    "url--paste": {
        "backgroundColor": "#fff",
        "minHeight": 200,
        "position": "relative"
    },
    "url--paste input": {
        "minHeight": 85,
        "minWidth": 230,
        "marginTop": 10,
        "marginRight": 15,
        "marginBottom": 10,
        "marginLeft": 15,
        "border": "1px solid #D0D0D0",
        "position": "relative"
    },
    "url--paste label": {
        "position": "absolute",
        "left": 25,
        "fontSize": 10,
        "top": "38%"
    }
});